jQuery(document).ready(function() {
	jQuery('span[id^="readMoreDesc"]').each(function() {
		var streamId = this.id.replace(/^readMoreDesc/, '');

		jQuery('#readMoreDesc' + streamId).on('shown.bs.collapse', function () {
			jQuery('#readMoreBtn' + streamId + ' .glyphicon').addClass('glyphicon-chevron-left').removeClass('glyphicon-chevron-right');
		});
		jQuery('#readMoreDesc' + streamId + '').on('hidden.bs.collapse', function () {
			jQuery('#readMoreBtn' + streamId + ' .glyphicon').addClass('glyphicon-chevron-right').removeClass('glyphicon-chevron-left');
		});
	});

	if (typeof(publicationServiceData) != 'undefined') {
		DilmotPublicationService.init(
			publicationServiceData.pusher_key, publicationServiceData.channel_name, publicationServiceData.stream_id
		);
	} else {
		console.error("Cannot init publication service listener - data is missing.")
	}

	if (typeof(load_published_from_dilmot) !== 'undefined' && load_published_from_dilmot) {
		jQuery.ajax({
			url: dilmot_api_url,
	    method: 'post',
    	data: load_published_data,
	    complete: function(jqXHR, textStatus) {
				switch (jqXHR.status) {
					case 200:
						var published_interactions = jqXHR.responseText
						jQuery(published_interactions).hide().appendTo("#stream_holder").fadeIn("slow");
						break;
					default:
						jQuery(error_html).hide().appendTo("#stream_holder").fadeIn("slow");
						console.error("Failed to load published interactions: " + jqXHR.responseText);
	      }
	    }
	  });
	}
});